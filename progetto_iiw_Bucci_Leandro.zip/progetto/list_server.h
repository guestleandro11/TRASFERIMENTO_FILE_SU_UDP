#include "basic.h"

void exe_list(struct temp_buf temp_buff,struct sel_repeat *shm);
