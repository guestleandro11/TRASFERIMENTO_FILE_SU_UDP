
//variabili globali
extern int msgid,queue_mtx_id,mtx_prefork_id,great_alarm_serv;//dopo le fork tutti i figli sanno quali sono gli id
extern struct params
 param_serv;
extern char*dir_server;
