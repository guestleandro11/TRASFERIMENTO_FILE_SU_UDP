#include "basic.h"

void exe_get(struct temp_buf temp_buff,struct sel_repeat *shm);
