extern int great_alarm_client;//se diventa 1 è scattato il timer globale
extern struct params
 param_client;
extern char *client_dir;
