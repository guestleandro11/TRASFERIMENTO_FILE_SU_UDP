#include "basic.h"

void list_client(struct sel_repeat *shm);
