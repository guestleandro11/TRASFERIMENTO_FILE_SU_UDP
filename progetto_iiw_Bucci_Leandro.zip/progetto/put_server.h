#include "basic.h"

void exe_put(struct temp_buf temp_buff,struct sel_repeat *shm);
