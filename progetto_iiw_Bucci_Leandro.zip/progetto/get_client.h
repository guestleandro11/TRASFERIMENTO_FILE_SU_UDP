#include "basic.h"

int wait_for_get_dimension(struct temp_buf temp_buff,struct sel_repeat *shm);
void get_client(struct sel_repeat *shm);
