#include "basic.h"

void put_client(struct sel_repeat *shm);
